package org.example;

public class Main {
    public static void main(String[] args) throws Exception {
        Humster humster = new Humster("Byria", "7", 200, "HIGH");
        Humster humster1 = new Humster("Murk", "8", 234, "LOW");
        Humster humster2 = new Humster("Valli", "3", 443, "MEDIUM");
        AnnotationProcessor.createTable(humster);
        AnnotationProcessor.insertIntoTable(humster);
        AnnotationProcessor.insertIntoTable(humster1);
        AnnotationProcessor.insertIntoTable(humster2);
    }
}
